# Exemplo da modelagem de um sistema bancário

Exemplo criado em sala de um projeto de banco para disciplina de pweb 2 do IFAL Rio Largo
