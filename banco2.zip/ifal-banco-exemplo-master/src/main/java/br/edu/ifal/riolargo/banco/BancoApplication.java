package br.edu.ifal.riolargo.banco;

import org.springframework.boot.CommandLineRunner;
//import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Bean;

import br.edu.ifal.riolargo.banco.modelo.Cliente;
import br.edu.ifal.riolargo.banco.modelo.Endereco;
import br.edu.ifal.riolargo.banco.repositorio.ClienteRepositorio;
import br.edu.ifal.riolargo.banco.repositorio.EnderecoRepositorio;

//import br.edu.ifal.riolargo.banco.modelo.Conta;


@SpringBootApplication
public class BancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BancoApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner demo(ClienteRepositorio cl_rep, EnderecoRepositorio ed_rep) {
		
		return (args) -> {
			Cliente c = new Cliente();
			c.setEmail("luanavasconcelos@gmail.com");
			c.setNome("Luana do Nascimento");
			
			Endereco e = new Endereco();
			e.setRua("Claudio Cardoso, 278");
			e.setCidade("Maceio");
			
			c.setEnd(e);
			
			ed_rep.save(e);
			
			cl_rep.save(c);
			
			
					
			};
		}
	}

	



