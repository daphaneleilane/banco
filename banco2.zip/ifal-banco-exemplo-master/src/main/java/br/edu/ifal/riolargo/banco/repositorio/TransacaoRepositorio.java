package br.edu.ifal.riolargo.banco.repositorio;

public interface TransacaoRepositorio {

}
