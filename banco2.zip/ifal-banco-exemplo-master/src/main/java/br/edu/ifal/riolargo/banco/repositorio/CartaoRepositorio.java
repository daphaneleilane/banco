package br.edu.ifal.riolargo.banco.repositorio;

import org.springframework.data.repository.CrudRepository;

import br.edu.ifal.riolargo.banco.modelo.Cartao;

public interface CartaoRepositorio extends CrudRepository<Cartao, Long>{

}
